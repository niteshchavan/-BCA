from Models.DBDAO import DBDAO

class DAO():
    def __init__(self, app):
        self.db = DBDAO(app)

    def execute_query(self, query, values=None):
        return self.db.execute_query(query, values)

    def commit(self):
        self.db.commit()
