-- MySQL dump 10.13  Distrib 8.3.0, for Win64 (x86_64)
--
-- Host: localhost    Database: portfolio
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `portfolio`
--

DROP TABLE IF EXISTS `portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portfolio` (
  `Symbol_id` int NOT NULL,
  `Symbol_name` varchar(255) DEFAULT NULL,
  `LTP` decimal(10,2) DEFAULT NULL,
  `PrevClose` decimal(10,2) DEFAULT NULL,
  `Buy_Date` date DEFAULT NULL,
  `Buy_Price` decimal(10,2) DEFAULT NULL,
  `Buy_Qty` decimal(10,2) DEFAULT NULL,
  `Total_Cost` decimal(10,2) DEFAULT NULL,
  `Current_Value` decimal(10,2) DEFAULT NULL,
  `Total_Returns` decimal(10,2) DEFAULT NULL,
  `Percent_Change` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolio`
--

LOCK TABLES `portfolio` WRITE;
/*!40000 ALTER TABLE `portfolio` DISABLE KEYS */;
INSERT INTO `portfolio` VALUES (543257,'IRFC',136.80,140.30,'2024-03-11',144.95,20.00,2899.00,2736.00,-163.00,-5.62),(543257,'IRFC',136.80,140.30,'2024-02-14',154.95,3.00,464.85,410.40,-54.45,-11.71),(543940,'JIO Finance',344.70,338.45,'2024-03-11',346.90,3.00,1040.70,1034.10,-6.60,-0.63),(543940,'JIO Finance	',344.70,338.45,'2024-03-11',349.20,20.00,6984.00,6894.00,-90.00,-1.29),(542651,'KPITTECH',1429.00,1424.80,'2024-02-09',1695.00,6.00,10170.00,8574.00,-1596.00,-15.69),(542651,'KPITTECH',1429.00,1424.80,'2024-02-09',1695.00,2.00,3390.00,2858.00,-532.00,-15.69),(542649,'RVNL',245.80,243.40,'2024-03-11',250.20,20.00,5004.00,4916.00,-88.00,-1.76),(500114,'TITAN',3633.00,3640.85,'2024-03-11',3796.70,1.00,3796.70,3633.00,-163.70,-4.31),(540180,'VBL',1432.85,1414.40,'2024-02-09',1367.10,8.00,10936.80,11462.80,526.00,4.81);
/*!40000 ALTER TABLE `portfolio` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`nitesh`@`%`*/ /*!50003 TRIGGER `calculate_portfolio_values_insert` BEFORE INSERT ON `portfolio` FOR EACH ROW BEGIN
    SET NEW.Total_Cost = NEW.Buy_Qty * NEW.Buy_Price;
    SET NEW.Current_Value = NEW.Buy_Qty * NEW.LTP;
    SET NEW.Total_Returns = NEW.Current_Value - NEW.Total_Cost;
    IF NEW.Total_Cost <> 0 THEN
        SET NEW.Percent_Change = (NEW.Total_Returns / NEW.Total_Cost) * 100;
    ELSE
        SET NEW.Percent_Change = 0;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`nitesh`@`%`*/ /*!50003 TRIGGER `calculate_portfolio_values_update` BEFORE UPDATE ON `portfolio` FOR EACH ROW BEGIN
    SET NEW.Total_Cost = NEW.Buy_Qty * NEW.Buy_Price;
    SET NEW.Current_Value = NEW.Buy_Qty * NEW.LTP;
    SET NEW.Total_Returns = NEW.Current_Value - NEW.Total_Cost;
    IF NEW.Total_Cost <> 0 THEN
        SET NEW.Percent_Change = (NEW.Total_Returns / NEW.Total_Cost) * 100;
    ELSE
        SET NEW.Percent_Change = 0;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-09  9:01:37
