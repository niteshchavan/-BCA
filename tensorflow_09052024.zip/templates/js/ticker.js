

// Ticker Tape
window.addEventListener('DOMContentLoaded', function() {
    // Function to fetch data with delay
    function fetchDataWithDelay() {
        setTimeout(fetchData, 2000); // Add a delay of 2000 milliseconds (2 seconds)
    }

    // Function to fetch data
    function fetchData() {
        fetch("/ticker")
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const marqueeElement = document.getElementById("ticker-marquee");
                marqueeElement.innerHTML = ""; // Clear previous data

                if (!data.success) {
                    throw new Error('Request was not successful');
                }

                if (!Array.isArray(data.stock_data)) {
                    throw new Error('Stock data is not an array');
                }

                data.stock_data.forEach(stock => {
                    const symbolSpan = document.createElement("span");
                    symbolSpan.classList.add("symbol");
                    symbolSpan.textContent = `${stock.Name.toUpperCase()} : ${stock.LTP}`;

                    const trendSpan = document.createElement("span");
                    if (parseFloat(stock.LTP) > parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "green";
                        trendSpan.textContent = "▲";
                    } else if (parseFloat(stock.LTP) < parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "red";
                        trendSpan.textContent = "▼";
                    } else {
                        trendSpan.textContent = "↔";
                    }

                    symbolSpan.appendChild(trendSpan);
                    marqueeElement.appendChild(symbolSpan);
                });
            })
            .catch(error => {
                console.error("Error fetching data:", error);
            });
    }

    // Initial fetch with delay
    fetchDataWithDelay();

    // Refresh data every minute
    setInterval(fetchData, 60000);
});
