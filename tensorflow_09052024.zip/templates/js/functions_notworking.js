
function showProgressModal() {
    $('#progressModal').modal('show'); // Show the progress modal
}

function hideProgressModal() {
    $('#progressModal').modal('hide'); // Hide the progress modal
}

$(document).ready(function() {
    $('#post-data-form').on('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally
        showProgressModal(); // Show progress modal when form is submitted
		$('#progressModal .modal-body').html('<p>Please wait while we process your data...</p>');
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'), // Get the form action dynamically
            data: $(this).serialize(),
            success: function(response) {
                
                if (response.success) {
                    $('#progressModal .modal-body').html('<p>Data updated successfully!</p>');
                    
                } else {
                    $('#progressModal .modal-body').html('<p>Error updating data.</p>');
					 
                }
            },
            error: function() {
                
                $('#progressModal .modal-body').html('<p>Error updating data.</p>');
            }
        });
    });
});

function portfolio() {
    $('#progressModal').modal('show');
    $('#progressModal .modal-body').html('<p>Please wait while we process your data...</p>');
  
    fetch(`/portfolio`, {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            $('#progressModal .modal-body').html('<p>Data updated successfully!</p>');
        } else {
            $('#progressModal .modal-body').html('<p>Error updating data.</p>');
        }
    })
    .catch(error => {
        console.error("Error retrieving data:", error);
    });
}

var ticker = document.getElementById("ticker-marquee");

function pauseTicker() {
    ticker.stop();
}

function resumeTicker() {
    ticker.start();
}




window.addEventListener('DOMContentLoaded', function() {
    function fetchData() {
        fetch("/get_symbols")
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                
                const symbolDropdown = document.getElementById("symbolDropdown");
                data.forEach(symbol => {
					const uppercaseSymbol = symbol.toUpperCase();
                    const option = document.createElement("option");
                    option.value = uppercaseSymbol;
                    option.textContent = uppercaseSymbol;
                    symbolDropdown.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    fetchData();
});




// Update data when a symbol is selected from the dropdown
function retrieveData() {
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/get_data/${symbol}`)
        .then(response => response.json())
        .then(data => {
			
            updateTable(data);
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
        });
}


function updateTable(data) {
    // Find the table body element
    const tableBody = document.getElementById("table-body");

    // Clear previous data from the table
    tableBody.innerHTML = "";

    // Define the order of the keys for the table columns
    const columnOrder = ['Date', 'Open', 'High', 'Low', 'Close'];

    // Iterate over the retrieved data and create table rows
    data.forEach(rowData => {
        const row = document.createElement("tr");

        // Iterate over each key in the specified order and create table cells
        columnOrder.forEach(key => {
            const cell = document.createElement("td");
            if (key === 'Date') {
                cell.textContent = formatDate(rowData[key]);
            } else {
                cell.textContent = rowData[key];
            }
            row.appendChild(cell);
        });

        // Append the row to the table body
        tableBody.appendChild(row);
    });
}


function updateData() {
	$('#progressModal').modal('show');
	$('#progressModal .modal-body').html('<p>Please wait while we process your data...</p>');
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/update_data/${symbol}`)
        .then(response => {
			
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
				$('#progressModal .modal-body').html('<p>Data updated successfully!</p>');
           
            } else {
				$('#progressModal .modal-body').html('<p>Error updating data.</p>');
            }
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
        });
}

function TrainData() {
	$('#progressModal').modal('show');
	$('#progressModal .modal-body').html('<p>Please wait while we process your data...</p>');
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/train_data/${symbol}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
				$('#progressModal .modal-body').html('<p>Data updated successfully!</p>');
                

            } else {
				$('#progressModal .modal-body').html('<p>Error updating data.</p>');
                
            }
        })
        .catch(error => {
			
            console.error("Error retrieving data:", error);
            alert("Error processing stock data");
        });
}





function predict() {
    const symbol = document.getElementById("symbolDropdown").value.toUpperCase();
	
    // Check if symbol is selected
    if (!symbol) {
        alert("Please select a symbol");
        return;
    }

    fetch(`/prediction/${symbol}`)
        .then(response => {
            if (response.status === 404) {
                throw new Error('Model not found');
            }
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            chart(data);

            fetch(`/get_data/${symbol}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);
					const container = document.getElementById('container');
					container.innerHTML = ''; // Clear existing data

					var chart;
					if (chart) {
						chart.dispose(); // Dispose of the previous chart instance
					}
					chart = anychart.stock();

					var table = anychart.data.table('Date');

					table.addData(data);
					var mapping = table.mapAs();
					var mapping = table.mapAs({'open':'Open','high': 'High','low': 'Low','close': 'Close'});
					
					var plot = chart.plot(0);	
					plot.xGrid(true).yGrid(true);
					// set orientation y-axis to the right side
					
					
					var series = plot.candlestick(mapping)
					series.name(symbol).zIndex(50);					
						series
						  .risingFill('green', 0.5)
						  .fallingFill('red', 0.5)
						  .risingStroke('green', 0.5)
						  .fallingStroke('red', 0.5);
					chart.container('container');
					chart.draw();
					
                })
                .catch(error => {
                    console.error("Error retrieving data:", error);
                });
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
            if (error.message === 'Model not found') {
                alert("Model not found for the selected symbol. Please Train Model First");
            } else {
                alert("Error retrieving data. Please try again later.");
            }
        });
}

function aiml() {
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/aiml/${symbol}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            
			const ltp = data.LTP;
			document.getElementById("current-price").value = ltp;

        })
        .catch(error => {
			
            console.error("Error retrieving data:", error);
            alert("Error processing stock data");
        });
}

document.getElementById("quantity").addEventListener("input", function() {
    const quantity = parseFloat(this.value);
    const currentPrice = parseFloat(document.getElementById("current-price").value);
    if (!isNaN(quantity) && !isNaN(currentPrice)) {
        const total = (quantity * currentPrice).toFixed(2); // Calculate total with two decimal places
        document.getElementById("total").value = total;
    } else {
        document.getElementById("total").value = "";
    }
});

function BuyOrder() {
    const symbol = document.getElementById("symbolDropdown").value;
    const currentPrice = document.getElementById("current-price").value;
    const quantity = document.getElementById("quantity").value;
    const total = document.getElementById("total").value;
    const stopLoss = document.getElementById("stoploss").value;
    
    // Get current date and time
    // Get current date and time
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    const dateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    console.log(dateTime)
	// Define order type
	const orderType = "Buy";
	
    // Prepare data to be sent to the server
    const orderData = {
        symbol: symbol,
        currentPrice: currentPrice,
        quantity: quantity,
        total: total,
        stopLoss: stopLoss,
        dateTime: dateTime,
		orderType: orderType
    };
    
    // Send data to server
    fetch('/saveOrder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(orderData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save order');
        }
        return response.json();
    })
    .then(data => {
        console.log('Order saved successfully:', data);
		window.alert('Order saved successfully!');
        // Reset form or show success message
		window.location.href = '/aiml.html';
    })
    .catch(error => {
        console.error('Error saving order:', error);
		window.alert('Failed to save order. Please try again.');
        // Show error message to the user
    });
}

function SellOrder() {
    const symbol = document.getElementById("symbolDropdown").value;
    const currentPrice = document.getElementById("current-price").value;
    const quantity = document.getElementById("quantity").value;
    const total = document.getElementById("total").value;
    const stopLoss = document.getElementById("stoploss").value;
    // Get current date and time
    const dateTime = new Date().toISOString().slice(0, 19).replace('T', ' ');

	// Define order type
	const orderType = "Sell";
    
    // Prepare data to be sent to the server
    const orderData = {
        symbol: symbol,
        currentPrice: currentPrice,
        quantity: quantity,
        total: total,
        stopLoss: stopLoss,
        dateTime: dateTime,
		orderType: orderType
    };
    
    // Send data to server
    fetch('/saveOrder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(orderData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to save order');
        }
        return response.json();
    })
    .then(data => {
		window.alert('Order saved successfully!');
		window.location.href = '/aiml.html';
        console.log('Order saved successfully:', data);
        // Reset form or show success message
    })
    .catch(error => {
        console.error('Error saving order:', error);
		window.alert('Failed to save order. Please try again.');
        // Show error message to the user
    });
}

function chart(data) {
    // Destroy existing chart if it exists
    if (window.myChart3) {
        window.myChart3.destroy();
    }

	var ctx1 = $("#line-chart").get(0).getContext("2d");
	window.myChart3 = new Chart(ctx1, {
		type: "line",
		data: {
			labels: data.dates,
			datasets: [{
					label: "Close Price",
					data: data.historical_prices.map((price, index) => index < data.dates.length - 5 ? price : null),
					backgroundColor: "rgba(0, 156, 255, .7)"
				},
				{
					label: "Predicted",
					data: Array(data.dates.length - 5).fill(null).concat(data.predicted_prices.slice(-5)),
					backgroundColor: "rgba(255, 0, 0, .7)"
				},
			]
		},
		options: {
			responsive: true
		}
	});


}


function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const monthIndex = date.getMonth();
    const year = date.getFullYear();

    return `${day}-${monthNames[monthIndex]}-${year}`;
}



window.addEventListener('DOMContentLoaded', function() {
    function fetchDataWithDelay() {
        setTimeout(fetchData, 2000); // Add a delay of 2000 milliseconds (2 seconds)
    }
    
    // Function to fetch data for both gainers and losers
    function fetchData() {
        fetch("/trending/gainers") // Fetch data for gainers
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Populate top gainers table
                const topGainersBody = document.getElementById('topGainersBody');
                topGainersBody.innerHTML = ''; // Clear existing data
                data.scrip_data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.scrip_id}</td>
						<td>${item.Ltradert}</td>
                        <td>${item.change_percent}</td>
                        <td>${item.change_val}</td>
                    `;
                    topGainersBody.appendChild(row);
                });
            })
            .catch(error => {
                console.error("Error fetching top gainers:", error);
            });

        fetch("/trending/loosers") // Fetch data for losers
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Populate top losers table
                const topLosersBody = document.getElementById('topLosersBody');
                topLosersBody.innerHTML = ''; // Clear existing data
                data.scrip_data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.scrip_id}</td>
						<td>${item.Ltradert}</td>
                        <td>${item.change_percent}</td>
                        <td>${item.change_val}</td>
                    `;
                    topLosersBody.appendChild(row);
                });
            })
            .catch(error => {
                console.error("Error fetching top losers:", error);
            });
    }
    
    // Initial fetch with delay
    fetchDataWithDelay();

    // Refresh data every minute
});

// Ticker Tape
window.addEventListener('DOMContentLoaded', function() {
    // Function to fetch data with delay
    function fetchDataWithDelay() {
        setTimeout(fetchData, 2000); // Add a delay of 2000 milliseconds (2 seconds)
    }

    // Function to fetch data
    function fetchData() {
        fetch("/ticker")
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const marqueeElement = document.getElementById("ticker-marquee");
                marqueeElement.innerHTML = ""; // Clear previous data

                if (!data.success) {
                    throw new Error('Request was not successful');
                }

                if (!Array.isArray(data.stock_data)) {
                    throw new Error('Stock data is not an array');
                }

                data.stock_data.forEach(stock => {
                    const symbolSpan = document.createElement("span");
                    symbolSpan.classList.add("symbol");
                    symbolSpan.textContent = `${stock.Name.toUpperCase()} : ${stock.LTP}`;

                    const trendSpan = document.createElement("span");
                    if (parseFloat(stock.LTP) > parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "green";
                        trendSpan.textContent = "▲";
                    } else if (parseFloat(stock.LTP) < parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "red";
                        trendSpan.textContent = "▼";
                    } else {
                        trendSpan.textContent = "↔";
                    }

                    symbolSpan.appendChild(trendSpan);
                    marqueeElement.appendChild(symbolSpan);
                });
            })
            .catch(error => {
                console.error("Error fetching data:", error);
            });
    }

    // Initial fetch with delay
    fetchDataWithDelay();

    // Refresh data every minute
    setInterval(fetchData, 2000);
});


