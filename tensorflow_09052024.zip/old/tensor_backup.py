import tensorflow as tf
import numpy as np
from flask import Flask
import os 

app = Flask(__name__)
app.secret_key = os.urandom(24)

sample_data = np.array([[1.0, 2.0, 3.0],
                        [4.0, 5.0, 6.0],
                        [7.0, 8.0, 9.0]])

@app.route('/train/<symbol>')
def train_data(symbol):
    # Define Sequential model with 3 layers
    model = tf.keras.Sequential(
        [
            tf.keras.layers.Dense(2, activation="relu", name="layer1"),
            tf.keras.layers.Dense(3, activation="relu", name="layer2"),
            tf.keras.layers.Dense(4, name="layer3"),
        ]
    )
    # Call model on the sample_data for prediction
    y = model(sample_data)
    model.save(f'models/{symbol}.keras')
    return str(y)

@app.route('/prediction/<symbol>')
def prediction(symbol):
    # Load the model
    model = tf.keras.models.load_model(f'models/{symbol}.keras')
    model.summary()
    print(model)
    return str(model)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
