function showPopup() {
    alert("Stock data processed successfully!");
    return true; // Allow form submission
}

function showProgressModal() {
    $('#progressModal').modal('show'); // Show the progress modal
}

function hideProgressModal() {
    $('#progressModal').modal('hide'); // Hide the progress modal
}

$(document).ready(function() {
    $('form').on('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally
        showProgressModal(); // Show progress modal when form is submitted
        $.ajax({
            type: 'POST',
            url: '/process_script_data',
            data: $(this).serialize(),
            success: function(response) {
                hideProgressModal(); // Hide progress modal on success
                if (response.success) {
                    alert("Stock data processed successfully!"); // Show success message
					location.reload();
                } else {
                    alert('Error processing stock data'); // Show error message if processing fails
                }
            },
            error: function() {
                hideProgressModal(); // Hide progress modal on error
                alert('Error processing stock data'); // Show error message if AJAX request fails
            }
        });
    });
});

window.addEventListener('DOMContentLoaded', function() {
    function fetchData() {
        fetch("/get_symbols")
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log(data);
                const symbolDropdown = document.getElementById("symbolDropdown");
                data.forEach(symbol => {
                    const option = document.createElement("option");
                    option.value = symbol;
                    option.textContent = symbol;
                    symbolDropdown.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    fetchData();
});




// Update data when a symbol is selected from the dropdown
function retrieveData() {
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/get_data/${symbol}`)
        .then(response => response.json())
        .then(data => {
			console.log(data)
            updateTable(data);
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
        });
}

function updateData() {
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/update_data/${symbol}`)
        .then(response => {
			
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                alert("Updated successfully!"); // Show success message

            } else {
                alert('Error processing '); // Show error message if processing fails
            }
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
        });
}

function TrainData() {
    const symbol = document.getElementById("symbolDropdown").value;
    fetch(`/train_data/${symbol}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                alert("Model Trained successfully!"); // Show success message

            } else {
                alert('Error processing '); // Show error message if processing fails
            }
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
            alert("Error processing stock data");
        });
}


function predict() {
    const symbol = document.getElementById("symbolDropdown").value;

    // Check if symbol is selected
    if (!symbol) {
        alert("Please select a symbol");
        return;
    }

    fetch(`/prediction/${symbol}`)
        .then(response => {
            if (response.status === 404) {
                throw new Error('Model not found');
            }
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            chart(data);
        })
        .catch(error => {
            console.error("Error retrieving data:", error);
            if (error.message === 'Model not found') {
                alert("Model not found for the selected symbol Please Train Model First");
            } else {
                alert("Error retrieving data. Please try again later.");
            }
        });
}



function chart(data) {
    // Destroy existing chart if it exists
    if (window.myChart3) {
        window.myChart3.destroy();
    }

	var ctx1 = $("#line-chart").get(0).getContext("2d");
	window.myChart3 = new Chart(ctx1, {
		type: "line",
		data: {
			labels: data.dates,
			datasets: [{
					label: "Close Price",
					data: data.historical_prices.map((price, index) => index < data.dates.length - 5 ? price : null),
					backgroundColor: "rgba(0, 156, 255, .7)"
				},
				{
					label: "Predicted",
					data: Array(data.dates.length - 5).fill(null).concat(data.predicted_prices.slice(-5)),
					backgroundColor: "rgba(255, 0, 0, .7)"
				},
			]
		},
		options: {
			responsive: true
		}
	});


}


function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const monthIndex = date.getMonth();
    const year = date.getFullYear();

    return `${day}-${monthNames[monthIndex]}-${year}`;
}


function updateTable(data) {
    // Find the table body element
    const tableBody = document.getElementById("table-body");

    // Clear previous data from the table
    tableBody.innerHTML = "";

    // Define the order of the keys for the table columns
    const columnOrder = ['Date', 'Open', 'High', 'Low', 'Close'];

    // Iterate over the retrieved data and create table rows
    data.forEach(rowData => {
        const row = document.createElement("tr");

        // Iterate over each key in the specified order and create table cells
        columnOrder.forEach(key => {
            const cell = document.createElement("td");
            if (key === 'Date') {
                cell.textContent = formatDate(rowData[key]);
            } else {
                cell.textContent = rowData[key];
            }
            row.appendChild(cell);
        });

        // Append the row to the table body
        tableBody.appendChild(row);
    });
}
// Ticker Tape
window.addEventListener('DOMContentLoaded', function() {
    // Function to fetch data with delay
    function fetchDataWithDelay() {
        setTimeout(fetchData, 2000); // Add a delay of 2000 milliseconds (2 seconds)
    }

    // Function to fetch data
    function fetchData() {
        fetch("http://192.168.0.100:5000/ticker")
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const marqueeElement = document.getElementById("ticker-marquee");
                marqueeElement.innerHTML = ""; // Clear previous data

                if (!data.success) {
                    throw new Error('Request was not successful');
                }

                if (!Array.isArray(data.stock_data)) {
                    throw new Error('Stock data is not an array');
                }

                data.stock_data.forEach(stock => {
                    const symbolSpan = document.createElement("span");
                    symbolSpan.classList.add("symbol");
                    symbolSpan.textContent = `${stock.Name.toUpperCase()} : ${stock.LTP}`;

                    const trendSpan = document.createElement("span");
                    if (parseFloat(stock.LTP) > parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "green";
                        trendSpan.textContent = "▲";
                    } else if (parseFloat(stock.LTP) < parseFloat(stock.Previous_Close)) {
                        trendSpan.style.color = "red";
                        trendSpan.textContent = "▼";
                    } else {
                        trendSpan.textContent = "↔";
                    }

                    symbolSpan.appendChild(trendSpan);
                    marqueeElement.appendChild(symbolSpan);
                });
            })
            .catch(error => {
                console.error("Error fetching data:", error);
            });
    }

    // Initial fetch with delay
    fetchDataWithDelay();

    // Refresh data every minute
    setInterval(fetchData, 60000);
});

window.addEventListener('DOMContentLoaded', function() {
    function fetchDataWithDelay() {
        setTimeout(fetchData, 2000); // Add a delay of 2000 milliseconds (2 seconds)
    }
    
    // Function to fetch data for both gainers and losers
    function fetchData() {
        fetch("/trending/gainers") // Fetch data for gainers
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Populate top gainers table
                const topGainersBody = document.getElementById('topGainersBody');
                topGainersBody.innerHTML = ''; // Clear existing data
                data.scrip_data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.scrip_id}</td>
						<td>${item.Ltradert}</td>
                        <td>${item.change_percent}</td>
                        <td>${item.change_val}</td>
                    `;
                    topGainersBody.appendChild(row);
                });
            })
            .catch(error => {
                console.error("Error fetching top gainers:", error);
            });

        fetch("/trending/loosers") // Fetch data for losers
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Populate top losers table
                const topLosersBody = document.getElementById('topLosersBody');
                topLosersBody.innerHTML = ''; // Clear existing data
                data.scrip_data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.scrip_id}</td>
						<td>${item.Ltradert}</td>
                        <td>${item.change_percent}</td>
                        <td>${item.change_val}</td>
                    `;
                    topLosersBody.appendChild(row);
                });
            })
            .catch(error => {
                console.error("Error fetching top losers:", error);
            });
    }
    
    // Initial fetch with delay
    fetchDataWithDelay();

    // Refresh data every minute
});

// Anychart data


anychart.onDocumentReady(function () {
    fetch('/get_data/TCS')
        .then(response => response.json())
        .then(data => {
            var table = anychart.data.table();
            table.addData(data);
			console.log(data)
             // Mapping the data  
            var mapping = table.mapAs();
            mapping.addField('open', 'Open');
            mapping.addField('high', 'High');
            mapping.addField('low', 'Low');
            mapping.addField('close', 'Close');
            mapping.addField('value', 'Close');  // Assuming 'value' is used for volume, but it's not present in your data

            // Defining the chart type
            var chart = anychart.stock();
  
            // Set the series type
            chart.plot(0).ohlc(mapping).name('TCS');

            // Setting the chart title
            chart.title('TCS Stock Data');

            // Display the chart
            chart.container('container');
            chart.draw(); 
        })
        .catch(error => console.error('Error fetching data:', error));
});