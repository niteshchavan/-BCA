import requests, csv, mysql.connector
import os
import numpy as np
import tensorflow as tf


from flask import Flask, request, render_template, redirect, url_for, session, send_from_directory, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from io import StringIO
from datetime import datetime, timedelta
from decimal import Decimal



os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow messages
#0: Display all logs (default behavior)
#1: Display only info logs
#2: Display only warning and error logs
#3: Display only error logs



app = Flask(__name__)
app.secret_key = os.urandom(24)



db = mysql.connector.connect(
    host="localhost",
    user="nitesh",
    password="root@123",
    database="stocks"
)


    
@app.route('/img/<path:filename>')
def get_image(filename):
    return send_from_directory('templates/img', filename)

@app.route('/lib/<path:filename>')
def get_lib(filename):
    return send_from_directory('templates/lib', filename)

@app.route('/css/<path:filename>')
def get_css(filename):
    return send_from_directory('templates/css', filename)

@app.route('/js/<path:filename>')
def get_js(filename):
    return send_from_directory('templates/js', filename)



@app.route('/')
def index():
    email = session.get('email')
    if 'email' in session:
        
        return render_template('index.html', email=email)
    return redirect(url_for('signin'))
    

# Route for rendering HTML pages
@app.route('/<page>')
def render_page(page):
    if page == 'signup.html':
        return render_template(f'{page}')
    if 'email' in session:
        email = session['email']
        return render_template(f'{page}', email=email)
    return redirect(url_for('signin'))    


    
 
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    print('in sighup.html')
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        # Hash the password
        hashed_password = generate_password_hash(password) 
        cursor = db.cursor()        
        # Insert username and hashed password into the database
        cursor.execute("INSERT INTO logins (email, password) VALUES (%s, %s)", (email, hashed_password))
        db.commit()
        cursor.close()
    return redirect(url_for('index'))

    
@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        #form_data = request.form
        
        #for key, value in form_data.items():
        #    print(f"Key: {key}, Value: {value}")
        
        email = request.form['email']
        password = request.form['password']
        #print(email,password)
        # Query the database to retrieve hashed password
        cursor = db.cursor()
        cursor.execute("SELECT password FROM logins WHERE email = %s", (email,))
        result = cursor.fetchone()
        cursor.close()
        if result:
            stored_password = result[0]
            if check_password_hash(stored_password, password):
                session['email'] = email
                return redirect(url_for('index'))
        
        return 'Invalid username/password'
    
    return render_template('signin.html')    

@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('signin'))


#fetch symbols in dropdown list 
@app.route('/get_symbols')
def get_symbols():
    if 'email' in session:
        try:
            # Query to retrieve distinct symbols from the stocks_price table
            cursor = db.cursor()
            cursor.execute("show tables")
            
            tables = [row[0] for row in cursor.fetchall() if row[0] not in ('logins', 'portfolio')] # Filter out 'logins' table
            cursor.close()
            return jsonify(tables)
        except Exception as e:
            return jsonify(error=str(e)), 500
    return redirect(url_for('signin'))
    
@app.route('/get_data/<symbol>')
def get_data(symbol):
    if 'email' in session:
        try:
            # Check if the table exists
            cursor = db.cursor()
            cursor.execute("SHOW TABLES LIKE %s", (symbol,))
            table_exists = cursor.fetchone()
            if not table_exists:
                return jsonify(error=f"Table '{symbol}' does not exist."), 404
            
            # Query the database for data related to the given symbol, ordered by Date in descending order
            query = f"SELECT Date, Open_Price, High_Price, Low_Price, Close_Price FROM {symbol} ORDER BY Date DESC LIMIT 50"
            
            cursor.execute(query)
            data = cursor.fetchall()
            cursor.close()
            # Convert the data to a list of dictionaries and reorder the keys
            result = []
            for row in data:
                # Convert the date to a string before parsing
                result.append({
                    'Date': row[0],  # Ensure Date is placed last                
                    'Open': row[1],
                    'High': row[2],
                    'Low': row[3],
                    'Close': row[4]
                })
            
            # Return the data as JSON response
            return jsonify(result)
        except Exception as e:
            return jsonify(error=str(e)), 500
    return redirect(url_for('signin'))


@app.route('/update_data/<symbol>')
def update_data(symbol):
    if 'email' in session:

        cursor = db.cursor()
        cursor.execute(f"SELECT Symbol_id FROM `{symbol}`Limit 1")
        data = cursor.fetchone()
        
        symbol_id = data[0]
        print(symbol_id)
        url = "https://api.bseindia.com/BseIndiaAPI/api/StockPriceCSVDownload/w"
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Referer": "https://www.bseindia.com/",
        }
        
        #01/02/2024 02/02/2024
        fromDate = '01/02/2024'
        #toDate = datetime.strptime(request.form['toDate'], '%Y-%m-%d').strftime('%d/%m/%Y')
        toDate = datetime.now().strftime('%d/%m/%Y')
        payload = {
            "pageType": "0",
            "rbType": "D",
            "Scode": symbol_id,
            "FDates": fromDate,
            "TDates": toDate
        }

        try:
            response = requests.get(url, headers=headers, params=payload, timeout=5)    
        except requests.exceptions.Timeout:
            return jsonify({"error": "Request timed out. Please try again later."}), 504    
        if response.status_code == 200:
            csv_buffer = StringIO(response.text)
            csv_reader = csv.DictReader(csv_buffer, delimiter='\t')
            for row in csv_reader:
                data = list(row.values())[0].split(',')
                date_str = data[0]
                date_obj = datetime.strptime(date_str, "%d-%B-%Y")
                mysql_date_format = date_obj.strftime("%Y-%m-%d")
                open_price = data[1]
                high_price = data[2]
                low_price = data[3]
                close_price = data[4]
                print(open_price, high_price, low_price, close_price)
                # Inserting data into respective table
                cursor.execute(
                    f"INSERT IGNORE INTO {symbol} (Symbol_id, Date, Open_Price, High_Price, Low_Price, Close_Price) VALUES (%s, %s, %s, %s, %s, %s)",
                    (symbol_id, mysql_date_format, open_price, high_price, low_price, close_price))
                db.commit()
            cursor.close()    
            return jsonify({'success': True})
        else:
            return jsonify({"error": "Failed to fetch data"}), response.status_code
    return redirect(url_for('signin'))


# Update Stocks Data from BSE API
@app.route('/process_script_data', methods=['POST'])
def process_script_data():
    if 'email' in session:        
        if request.method == 'POST':
            stock_data = request.form['stockData']
            fromDate = datetime.strptime(request.form['fromDate'], '%Y-%m-%d').strftime('%d/%m/%Y')
            toDate = datetime.strptime(request.form['toDate'], '%Y-%m-%d').strftime('%d/%m/%Y')
            print("Received stock data:", stock_data, fromDate, toDate)
            url = "https://api.bseindia.com/BseIndiaAPI/api/StockPriceCSVDownload/w"
            url2 = "https://api.bseindia.com/BseIndiaAPI/api/ComHeadernew/w"
            headers = {
                "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
                "Referer": "https://www.bseindia.com/",
            }

            # Extract script code from query parameters
            script_code = stock_data  # request.args.get('script_code')

            # for Stock Data
            payload = {
                "pageType": "0",
                "rbType": "D",
                "Scode": script_code,
                "FDates": fromDate,
                "TDates": toDate
            }
            # for Stock Name
            payload2 = {
                "quotetype": 'EQ',
                "scripcode": script_code,
                "seriesid": ""
            }

            try:
                response = requests.get(url, headers=headers, params=payload, timeout=5)
                response.raise_for_status()
                response2 = requests.get(url2, headers=headers, params=payload2, timeout=5).json()
            except requests.exceptions.Timeout:
                return jsonify({"error": "Request timed out. Please try again later."}), 504
            except requests.exceptions.RequestException as e:
                return jsonify({"error": f"An error occurred: {e}"}), 500

            symbol_name = response2.get("SecurityId", "")
            
            if response.status_code == 200:
                cursor = db.cursor()
                # Dynamically create table for each symbol if not exists
                cursor.execute(f"CREATE TABLE IF NOT EXISTS {symbol_name} (Symbol_id int, Date DATE, Open_Price FLOAT, High_Price FLOAT, Low_Price FLOAT, Close_Price FLOAT, UNIQUE (Date))")
                # Process CSV data line by line
                csv_buffer = StringIO(response.text)
                csv_reader = csv.DictReader(csv_buffer, delimiter='\t')

                for row in csv_reader:

                    # Extracting data from each row
                    data = list(row.values())[0].split(',')

                    date_str = data[0]
                    date_obj = datetime.strptime(date_str, "%d-%B-%Y")
                    mysql_date_format = date_obj.strftime("%Y-%m-%d")
                    open_price = data[1]
                    high_price = data[2]
                    low_price = data[3]
                    close_price = data[4]

                    # Inserting data into respective table
                    cursor.execute(
                        f"INSERT IGNORE INTO {symbol_name} (Symbol_id, Date, Open_Price, High_Price, Low_Price, Close_Price) VALUES (%s, %s, %s, %s, %s, %s)",
                        (script_code, mysql_date_format, open_price, high_price, low_price, close_price))
                    db.commit()
                cursor.close()    
                return jsonify({'success': True})
            else:
                return jsonify({"error": "Failed to fetch data"}), response.status_code
    return redirect(url_for('signin'))
    
    



@app.route('/ticker')
def ticker_data():
    if 'email' in session:
        url = "https://api.bseindia.com/BseIndiaAPI/api/getScripHeaderData/w"
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Referer": "https://www.bseindia.com/",
        }

        cursor = db.cursor()

        try:
            # Get distinct symbol_ids from all tables except 'logins'
            cursor.execute("SHOW TABLES")
            tables = [row[0] for row in cursor.fetchall() if row[0] not in ('logins', 'portfolio')]
            
            symbol_ids_set = set()  # Using a set to store unique symbol IDs
            #print(latest_data)
            #wait = input("Press Enter to continue.")
            for table in tables:
                cursor.execute(f"SELECT DISTINCT Symbol_id FROM {table}")
                distinct_symbol_ids = cursor.fetchall()
                symbol_ids_set.update(symbol_id[0] for symbol_id in distinct_symbol_ids)

            # Convert set to list for easier iteration
            symbol_ids_list = list(symbol_ids_set)
            
            # Fetch stock data for all symbol IDs in a single API call
            tdata = []
            
            for symbol_id in symbol_ids_list:
                payload = {
                    "Debtflag": "",
                    "scripcode": symbol_id,
                    "seriesid": "",
                }

                jsonData = requests.get(url, headers=headers, params=payload).json()

                stock_data = {}

                if "Cmpname" in jsonData:
                    stock_data["Name"] = jsonData["Cmpname"]["ShortN"]

                if "CurrRate" in jsonData:
                    stock_data["LTP"] = jsonData["CurrRate"]["LTP"]

                if "Header" in jsonData:
                    stock_data["Previous_Close"] = jsonData["Header"]["PrevClose"]

                tdata.append(stock_data)

            return jsonify({'success': True, 'stock_data': tdata})
            
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})

        finally:
            # Close cursor
            
            cursor.close()
    return redirect(url_for('signin'))


# Top Gainers/Loosers
@app.route('/trending/<trend_type>')
def trending(trend_type):
    if 'email' in session:
        url = "https://api.bseindia.com/BseIndiaAPI/api/HoTurnover/w"
        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Referer": "https://www.bseindia.com/",
        }

        if trend_type == 'gainers':
            payload = {"flag": "G"}
        elif trend_type == 'loosers':
            payload = {"flag": "L"}
        else:
            return jsonify({"error": "Invalid trending type"}), 400
         
        response = requests.get(url, headers=headers, params=payload, timeout=10)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Convert response to JSON format
            data = response.json()
            # Initialize a list to store scrip_ids and corresponding change_percent
            scrip_data = []
            # Iterate over each item in the "Table" key
            for item in data.get("Table", []):
                # Extract the "scrip_id" and "change_percent"
                scrip_id = item.get("scrip_id")
                Ltradert = item.get("Ltradert")
                change_percent = item.get("change_percent")
                change_val = item.get("change_val")
                # Append the scrip_id and change_percent to the list
                scrip_data.append({"scrip_id": scrip_id, "Ltradert": Ltradert, "change_percent": change_percent,"change_val": change_val})
            # Return the list of scrip_ids and change_percent as JSON
            return jsonify({"scrip_data": scrip_data})
        else:
            # If request failed, return an error message
            return jsonify({"error": "Failed to fetch trending data"}), response.status_code
    return redirect(url_for('signin'))





@app.route('/train_data/<symbol>')
def train_data(symbol):
    if 'email' in session:    
        # Fetch x_train and y_train from the database
        cursor = db.cursor()
        cursor.execute(f"SELECT Open_Price, High_Price, Low_Price, Close_Price FROM `{symbol}`")

        data = cursor.fetchall()
        
        cursor.close()
        

        # Convert data to suitable Python data types

        data = [(float(row[0]), float(row[1]), float(row[2]), float(row[3])) for row in data]

        x_train = np.array([row[:-1] for row in data])  # Exludes last element ie Close_Price from the data

        y_train = np.array([row[3] for row in data])    # Extracting only the Close_Price, 4th object
     
            
        # Define Sequential model with 3 layers
        model = tf.keras.Sequential(
            [
                tf.keras.layers.Dense(64, activation='relu', input_shape=(x_train.shape[1],)),
                tf.keras.layers.Dense(32, activation='relu'),
                tf.keras.layers.Dense(1),
            ]
        )
        # Call model on the sample_data for prediction
        # Compile the model
        model.compile(optimizer='adam',
                      loss='mean_squared_error',  # Mean squared error loss for regression
                      metrics=['mae'])  # Mean absolute error metric


        model.fit(x_train, y_train, epochs=10, batch_size=32)  # Adjust batch size as needed
        
        model.save(f'models/{symbol}.keras')
        return jsonify({'success': True})
    return redirect(url_for('signin'))

@app.route('/prediction/<symbol>')
def prediction(symbol):
    if 'email' in session:
        model_path = f'models\\{symbol}.keras'
        
        #Check if model is trained or not 
        if not os.path.exists(model_path):
            return jsonify(error='Model not available'), 404

        cursor = db.cursor()
        # Fetch historical data for the stock
        cursor.execute(f"SELECT Date, Open_Price, High_Price, Low_Price, Close_Price FROM {symbol} ORDER BY Date DESC Limit 20")
        historical_data = cursor.fetchall()
        
        cursor.close()

        # Convert decimal.Decimal values to float and format date
        historical_data = [(row[0].strftime('%Y-%m-%d'), float(row[1]), float(row[2]), float(row[3]), float(row[4])) for row in historical_data]
        historical_data.sort(key=lambda x: datetime.strptime(x[0], '%Y-%m-%d'))

        predicted_close_prices = []
                
        current_date = datetime.strptime(historical_data[-1][0], '%Y-%m-%d')  
        model = tf.keras.models.load_model(model_path)
        for _ in range(5):
            x_input = np.array([[historical_data[-1][1], historical_data[-1][2], historical_data[-1][3]]])
            predicted_close_price = model.predict(x_input)
            predicted_close_prices.append(float(predicted_close_price[0][0]))
            current_date += timedelta(days=1)
            historical_data.append((current_date.strftime('%Y-%m-%d'), float(predicted_close_price[0][0]), float(predicted_close_price[0][0]), float(predicted_close_price[0][0]), float(historical_data[-1][4])))
        model.summary()
        response_data = {
            "dates": [data_point[0] for data_point in historical_data],
            "historical_prices": [data_point[4] for data_point in historical_data],
            "predicted_prices": [float(price) for price in predicted_close_prices]
        }            
        return jsonify(response_data)
    return redirect(url_for('signin'))


@app.route('/portfolio', methods=['GET', 'POST'])
def portfolio():

    if request.method == 'POST':
        print("in post")
        # Handle update request
        update_portfolio_data()
        return jsonify({'success': True})
    # Fetch portfolio data
    cursor = db.cursor()
    cursor.execute("SELECT * FROM portfolio ORDER BY Buy_Date ASC;")
    data = cursor.fetchall()
    
    # Calculate totals
    total_cost = sum(stock[7] for stock in data)
    current_value = sum(stock[8] for stock in data)
    total_returns = sum(stock[9] for stock in data)
    percent_change = round((total_returns / total_cost) * 100, 2) if total_cost != 0 else 0
    
    cursor.close()
    print("in portfolio")

    return render_template('portfolio.html', portfolio=data, total_cost=total_cost, current_value=current_value, total_returns=total_returns, percent_change=percent_change)

def update_portfolio_data():
    try:
        with db.cursor() as cursor:
            cursor.execute("SELECT * FROM portfolio ORDER BY Buy_Date ASC;")
            data = cursor.fetchall()
            
            # Calculate totals
            total_cost = 0
            current_value = 0
            total_returns = 0
            
            for stock in data:
                symbol_id = stock[0]
                url = "https://api.bseindia.com/BseIndiaAPI/api/getScripHeaderData/w"
                headers = {
                    "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
                    "Referer": "https://www.bseindia.com/",
                }
                payload = {
                    "Debtflag": "",
                    "scripcode": symbol_id,
                    "seriesid": "",
                }

                try:
                    jsonData = requests.get(url, headers=headers, params=payload).json()

                    if "CurrRate" in jsonData:
                        LTP = jsonData["CurrRate"]["LTP"]
                    else:
                        LTP = None

                    if "Header" in jsonData:
                        PrevClose = jsonData["Header"]["PrevClose"]
                    else:
                        PrevClose = None
                    
                    # Update database with LTP and Previous_Close
                    cursor.execute("UPDATE portfolio SET LTP = %s, PrevClose = %s WHERE Symbol_id = %s", (LTP, PrevClose, symbol_id))
                    db.commit()
                    
                    total_cost += stock[7]
                    current_value += stock[8]
                    total_returns += stock[9]
                    
                except requests.exceptions.RequestException as e:
                    print(f"Error fetching data for symbol_id {symbol_id}: {e}")
    
    except mysql.connector.Error as e:
        print(f"Error fetching data: {e}")
    

@app.route('/add_stock', methods=['POST'])
def add_stock():
    if request.method == 'POST':
        try:
            symbol_name = request.form['symbol_name']
            symbol_id = request.form['symbol_id']
            buy_date = request.form['buy_date']
            buy_price = request.form['buy_price']
            buy_qty = request.form['buy_qty']
            
            # Fetch data from API
            url = "https://api.bseindia.com/BseIndiaAPI/api/getScripHeaderData/w"
            headers = {
                "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
                "Referer": "https://www.bseindia.com/",
            }
            payload = {
                "Debtflag": "",
                "scripcode": symbol_id,
                "seriesid": "",
            }
            response = requests.get(url, headers=headers, params=payload)
            response.raise_for_status()  # Raise an error if the request fails
            
            jsonData = response.json()
            
            LTP = jsonData.get("CurrRate", {}).get("LTP")
            PrevClose = jsonData.get("Header", {}).get("PrevClose")
            
            # Insert data into the database
            with db.cursor() as cursor:
                cursor.execute("INSERT INTO portfolio (Symbol_id, Symbol_name, Buy_Date, Buy_Price, Buy_Qty, LTP, PrevClose) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                               (symbol_id, symbol_name, buy_date, buy_price, buy_qty, LTP, PrevClose))
                db.commit()
            cursor.close()    
            return redirect(url_for('portfolio'))
        
        except (requests.exceptions.RequestException, mysql.connector.Error) as e:
            print(f"Error: {e}")
            return render_template('error.html', message="Error occurred while adding stock.")
    
    return redirect(url_for('portfolio'))


@app.route('/delete_stock/<int:symbol_id>', methods=['POST'])
def delete_stock(symbol_id):
    try:
        with db.cursor() as cursor:
            cursor.execute("DELETE FROM portfolio WHERE Symbol_id = %s", (symbol_id,))
            db.commit()
        cursor.close()
        return redirect(url_for('portfolio'))
    except mysql.connector.Error as e:
        print(f"Error deleting stock: {e}")
        return render_template('error.html', message="Error deleting stock from database.")


    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
    
    
    